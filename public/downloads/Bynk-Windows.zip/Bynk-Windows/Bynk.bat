@echo off
start "" wscript.exe "%~dp0Bynk.vbs"
