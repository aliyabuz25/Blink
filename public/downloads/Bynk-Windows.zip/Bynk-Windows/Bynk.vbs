Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
url = "https://blink.octotech.az?web=1"
edge1 = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
edge2 = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
chrome1 = "C:\Program Files\Google\Chrome\Application\chrome.exe"
chrome2 = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
If fso.FileExists(edge1) Then
  WshShell.Run """" & edge1 & """ --app=" & url & " --window-size=1180,780", 1, False
ElseIf fso.FileExists(edge2) Then
  WshShell.Run """" & edge2 & """ --app=" & url & " --window-size=1180,780", 1, False
ElseIf fso.FileExists(chrome1) Then
  WshShell.Run """" & chrome1 & """ --app=" & url & " --window-size=1180,780", 1, False
ElseIf fso.FileExists(chrome2) Then
  WshShell.Run """" & chrome2 & """ --app=" & url & " --window-size=1180,780", 1, False
Else
  WshShell.Run url, 1, False
End If
