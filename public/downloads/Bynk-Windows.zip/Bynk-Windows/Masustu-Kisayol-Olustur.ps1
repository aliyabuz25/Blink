$WshShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath("Desktop")
$Shortcut = $WshShell.CreateShortcut("$Desktop\Bynk.lnk")
$Shortcut.TargetPath = "wscript.exe"
$Shortcut.Arguments = "`"$PSScriptRoot\Bynk.vbs`""
$Shortcut.WorkingDirectory = $PSScriptRoot
$Shortcut.Description = "Bynk Desktop"
$Shortcut.Save()
Write-Host "Bynk masaustu kisayolu olusturuldu!" -ForegroundColor Green
